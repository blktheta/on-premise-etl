--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stg_filmrental;
--
-- Name: stg_filmrental; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stg_filmrental WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Swedish_Sweden.1252';


ALTER DATABASE stg_filmrental OWNER TO postgres;

\connect stg_filmrental

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dim; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dim;


ALTER SCHEMA dim OWNER TO postgres;

--
-- Name: fact; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA fact;


ALTER SCHEMA fact OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actor; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.actor (
    id integer NOT NULL,
    actor_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45) NOT NULL
);


ALTER TABLE dim.actor OWNER TO postgres;

--
-- Name: actor_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.actor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.actor_id_seq OWNER TO postgres;

--
-- Name: actor_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.actor_id_seq OWNED BY dim.actor.id;


--
-- Name: customer; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.customer (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45) NOT NULL,
    email character varying(50),
    address character varying(50) NOT NULL,
    district character varying(50) NOT NULL,
    postal_code character varying(10),
    city character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    phone character varying(20),
    create_date date NOT NULL
);


ALTER TABLE dim.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.customer_id_seq OWNED BY dim.customer.id;


--
-- Name: date; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.date (
    id integer NOT NULL,
    payment_id integer NOT NULL,
    payment_date timestamp without time zone NOT NULL,
    month_day smallint NOT NULL,
    month smallint NOT NULL,
    year smallint NOT NULL,
    week_day_str character(3) NOT NULL,
    month_str character(3) NOT NULL,
    week_day smallint NOT NULL,
    year_day smallint NOT NULL,
    year_week smallint NOT NULL,
    year_quarter smallint NOT NULL
);


ALTER TABLE dim.date OWNER TO postgres;

--
-- Name: date_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.date_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.date_id_seq OWNER TO postgres;

--
-- Name: date_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.date_id_seq OWNED BY dim.date.id;


--
-- Name: film; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.film (
    id integer NOT NULL,
    film_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    rental_duration smallint NOT NULL,
    rental_rate numeric(4,2) NOT NULL,
    length smallint,
    replacement_cost numeric(5,2) NOT NULL,
    rating character varying(5),
    category character varying(25) NOT NULL,
    trailers boolean NOT NULL,
    behind_the_scenes boolean NOT NULL,
    commentaries boolean NOT NULL,
    deleted_scenes boolean NOT NULL
);


ALTER TABLE dim.film OWNER TO postgres;

--
-- Name: film_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.film_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.film_id_seq OWNER TO postgres;

--
-- Name: film_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.film_id_seq OWNED BY dim.film.id;


--
-- Name: staff; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.staff (
    id integer NOT NULL,
    staff_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45) NOT NULL
);


ALTER TABLE dim.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.staff_id_seq OWNED BY dim.staff.id;


--
-- Name: store; Type: TABLE; Schema: dim; Owner: postgres
--

CREATE TABLE dim.store (
    id integer NOT NULL,
    store_id integer NOT NULL,
    manager_id integer NOT NULL,
    store_manager character varying(90) NOT NULL,
    address character varying(50) NOT NULL,
    district character varying(50) NOT NULL,
    postal_code character varying(10),
    city character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    phone character varying(20)
);


ALTER TABLE dim.store OWNER TO postgres;

--
-- Name: store_id_seq; Type: SEQUENCE; Schema: dim; Owner: postgres
--

CREATE SEQUENCE dim.store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dim.store_id_seq OWNER TO postgres;

--
-- Name: store_id_seq; Type: SEQUENCE OWNED BY; Schema: dim; Owner: postgres
--

ALTER SEQUENCE dim.store_id_seq OWNED BY dim.store.id;


--
-- Name: actors; Type: TABLE; Schema: fact; Owner: postgres
--

CREATE TABLE fact.actors (
    date_id integer NOT NULL,
    actor_id integer NOT NULL,
    film_id integer NOT NULL,
    customer_id integer NOT NULL,
    amount numeric(5,2) NOT NULL
);


ALTER TABLE fact.actors OWNER TO postgres;

--
-- Name: rentals; Type: TABLE; Schema: fact; Owner: postgres
--

CREATE TABLE fact.rentals (
    date_id integer NOT NULL,
    film_id integer NOT NULL,
    store_id integer NOT NULL,
    customer_id integer NOT NULL,
    rental_date timestamp without time zone NOT NULL,
    return_date timestamp without time zone NOT NULL,
    days_rented smallint NOT NULL,
    late_return boolean NOT NULL
);


ALTER TABLE fact.rentals OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: fact; Owner: postgres
--

CREATE TABLE fact.sales (
    date_id integer NOT NULL,
    staff_id integer NOT NULL,
    film_id integer NOT NULL,
    store_id integer NOT NULL,
    customer_id integer NOT NULL,
    amount numeric(5,2) NOT NULL
);


ALTER TABLE fact.sales OWNER TO postgres;

--
-- Name: actor id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.actor ALTER COLUMN id SET DEFAULT nextval('dim.actor_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.customer ALTER COLUMN id SET DEFAULT nextval('dim.customer_id_seq'::regclass);


--
-- Name: date id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.date ALTER COLUMN id SET DEFAULT nextval('dim.date_id_seq'::regclass);


--
-- Name: film id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.film ALTER COLUMN id SET DEFAULT nextval('dim.film_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.staff ALTER COLUMN id SET DEFAULT nextval('dim.staff_id_seq'::regclass);


--
-- Name: store id; Type: DEFAULT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.store ALTER COLUMN id SET DEFAULT nextval('dim.store_id_seq'::regclass);


--
-- Data for Name: actor; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.actor (id, actor_id, first_name, last_name) FROM stdin;
\.
COPY dim.actor (id, actor_id, first_name, last_name) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.customer (id, customer_id, first_name, last_name, email, address, district, postal_code, city, country, phone, create_date) FROM stdin;
\.
COPY dim.customer (id, customer_id, first_name, last_name, email, address, district, postal_code, city, country, phone, create_date) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: date; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.date (id, payment_id, payment_date, month_day, month, year, week_day_str, month_str, week_day, year_day, year_week, year_quarter) FROM stdin;
\.
COPY dim.date (id, payment_id, payment_date, month_day, month, year, week_day_str, month_str, week_day, year_day, year_week, year_quarter) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: film; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.film (id, film_id, title, description, rental_duration, rental_rate, length, replacement_cost, rating, category, trailers, behind_the_scenes, commentaries, deleted_scenes) FROM stdin;
\.
COPY dim.film (id, film_id, title, description, rental_duration, rental_rate, length, replacement_cost, rating, category, trailers, behind_the_scenes, commentaries, deleted_scenes) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.staff (id, staff_id, first_name, last_name) FROM stdin;
\.
COPY dim.staff (id, staff_id, first_name, last_name) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: store; Type: TABLE DATA; Schema: dim; Owner: postgres
--

COPY dim.store (id, store_id, manager_id, store_manager, address, district, postal_code, city, country, phone) FROM stdin;
\.
COPY dim.store (id, store_id, manager_id, store_manager, address, district, postal_code, city, country, phone) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: actors; Type: TABLE DATA; Schema: fact; Owner: postgres
--

COPY fact.actors (date_id, actor_id, film_id, customer_id, amount) FROM stdin;
\.
COPY fact.actors (date_id, actor_id, film_id, customer_id, amount) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: rentals; Type: TABLE DATA; Schema: fact; Owner: postgres
--

COPY fact.rentals (date_id, film_id, store_id, customer_id, rental_date, return_date, days_rented, late_return) FROM stdin;
\.
COPY fact.rentals (date_id, film_id, store_id, customer_id, rental_date, return_date, days_rented, late_return) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: fact; Owner: postgres
--

COPY fact.sales (date_id, staff_id, film_id, store_id, customer_id, amount) FROM stdin;
\.
COPY fact.sales (date_id, staff_id, film_id, store_id, customer_id, amount) FROM '$$PATH$$/3403.dat';

--
-- Name: actor_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.actor_id_seq', 200, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.customer_id_seq', 599, true);


--
-- Name: date_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.date_id_seq', 14596, true);


--
-- Name: film_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.film_id_seq', 1000, true);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.staff_id_seq', 2, true);


--
-- Name: store_id_seq; Type: SEQUENCE SET; Schema: dim; Owner: postgres
--

SELECT pg_catalog.setval('dim.store_id_seq', 2, true);


--
-- Name: actor actor_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.actor
    ADD CONSTRAINT actor_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: date date_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.date
    ADD CONSTRAINT date_pkey PRIMARY KEY (id);


--
-- Name: film film_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.film
    ADD CONSTRAINT film_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: dim; Owner: postgres
--

ALTER TABLE ONLY dim.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: actors actors_pkey; Type: CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.actors
    ADD CONSTRAINT actors_pkey PRIMARY KEY (date_id, actor_id, film_id, customer_id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (date_id, film_id, store_id, customer_id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (date_id, staff_id, film_id, store_id, customer_id);


--
-- Name: actors actors_actor_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.actors
    ADD CONSTRAINT actors_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES dim.actor(id);


--
-- Name: actors actors_customer_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.actors
    ADD CONSTRAINT actors_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES dim.customer(id);


--
-- Name: actors actors_date_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.actors
    ADD CONSTRAINT actors_date_id_fkey FOREIGN KEY (date_id) REFERENCES dim.date(id);


--
-- Name: actors actors_film_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.actors
    ADD CONSTRAINT actors_film_id_fkey FOREIGN KEY (film_id) REFERENCES dim.film(id);


--
-- Name: rentals rentals_customer_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.rentals
    ADD CONSTRAINT rentals_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES dim.customer(id);


--
-- Name: rentals rentals_date_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.rentals
    ADD CONSTRAINT rentals_date_id_fkey FOREIGN KEY (date_id) REFERENCES dim.date(id);


--
-- Name: rentals rentals_film_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.rentals
    ADD CONSTRAINT rentals_film_id_fkey FOREIGN KEY (film_id) REFERENCES dim.film(id);


--
-- Name: rentals rentals_store_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.rentals
    ADD CONSTRAINT rentals_store_id_fkey FOREIGN KEY (store_id) REFERENCES dim.store(id);


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES dim.customer(id);


--
-- Name: sales sales_date_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_date_id_fkey FOREIGN KEY (date_id) REFERENCES dim.date(id);


--
-- Name: sales sales_film_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_film_id_fkey FOREIGN KEY (film_id) REFERENCES dim.film(id);


--
-- Name: sales sales_staff_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES dim.staff(id);


--
-- Name: sales sales_store_id_fkey; Type: FK CONSTRAINT; Schema: fact; Owner: postgres
--

ALTER TABLE ONLY fact.sales
    ADD CONSTRAINT sales_store_id_fkey FOREIGN KEY (store_id) REFERENCES dim.store(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

